def main(event, context):
    return {
        'message': 'Hello, world!'
    }