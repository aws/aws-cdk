export declare const handler: (event: any, _context?: any) => Promise<any>;
