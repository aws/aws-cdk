export const CLUSTER_RESOURCE_TYPE = 'Custom::AWSCDK-EKS-Cluster';
export const FARGATE_PROFILE_RESOURCE_TYPE = 'Custom::AWSCDK-EKS-FargateProfile';