export declare const PROP_BUCKET_NAME = "BucketName";
export declare const PROP_OBJECT_KEY = "ObjectKey";
export declare const PROP_CONTENTS = "Contents";
export declare const PROP_PUBLIC = "PublicRead";
export declare const ATTR_ETAG = "ETag";
export declare const ATTR_URL = "URL";
export declare const ATTR_OBJECT_KEY = "ObjectKey";
