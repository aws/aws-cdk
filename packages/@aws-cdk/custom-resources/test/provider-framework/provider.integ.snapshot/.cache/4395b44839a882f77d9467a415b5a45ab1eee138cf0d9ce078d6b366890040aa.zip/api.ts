export const PROP_BUCKET_NAME = 'BucketName';
export const PROP_OBJECT_KEY = 'ObjectKey';
export const PROP_CONTENTS = 'Contents';
export const PROP_PUBLIC = 'PublicRead';

export const ATTR_ETAG = 'ETag';
export const ATTR_URL = 'URL';
export const ATTR_OBJECT_KEY = 'ObjectKey';
