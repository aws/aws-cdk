import argparse
import sys


def get_job_args(required_args, optional_args):
    lst = sys.argv
    reqd_args_map = get_resolved_options(lst, required_args, True)
    opt_args_map = {}

    for a in optional_args:
        opt_args_map[a] = ""
        try:
            r = get_resolved_options(lst, [a], False)
            if a in r:
                opt_args_map[a] = r[a]
            elif a.replace("-", "_") in r:
                opt_args_map[a.replace("-", "_")] = r[a.replace("-", "_")]
        except:
            print("Ignoring key " + a)

    merged_map = {}
    for k, v in opt_args_map.items():
        merged_map[k] = v

    for k,v in reqd_args_map.items():
        merged_map[k] = v
    return merged_map


def get_resolved_options(args, options, required=True):
    parser = argparse.ArgumentParser()
    for option in options:
        parser.add_argument('--' + option, required=required)
    parsed, extra = parser.parse_known_args(args)
    return vars(parsed)
