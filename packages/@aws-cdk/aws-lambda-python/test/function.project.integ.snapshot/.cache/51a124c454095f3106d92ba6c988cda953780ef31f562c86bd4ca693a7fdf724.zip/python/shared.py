def get_url() -> str:
  return 'https://a0.awsstatic.com/main/images/logos/aws_smile-header-desktop-en-white_59x35.png'
