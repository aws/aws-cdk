export declare function main(_event: any, _context: any): Promise<string>;
