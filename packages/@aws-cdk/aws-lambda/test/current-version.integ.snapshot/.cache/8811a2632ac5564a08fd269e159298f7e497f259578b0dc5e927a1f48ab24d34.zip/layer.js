"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
async function main(_event, _context) {
    return 'Done!';
}
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsYXllci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBTyxLQUFLLFVBQVUsSUFBSSxDQUFDLE1BQVcsRUFBRSxRQUFhO0lBQ25ELE9BQU8sT0FBTyxDQUFDO0FBQ2pCLENBQUM7QUFGRCxvQkFFQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYWluKF9ldmVudDogYW55LCBfY29udGV4dDogYW55KSB7XG4gIHJldHVybiAnRG9uZSEnO1xufVxuIl19