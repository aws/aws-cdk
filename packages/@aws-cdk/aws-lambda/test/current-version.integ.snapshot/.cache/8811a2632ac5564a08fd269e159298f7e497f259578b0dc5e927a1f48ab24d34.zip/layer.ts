export async function main(_event: any, _context: any) {
  return 'Done!';
}
