export declare const handler: (event: import("aws-lambda").APIGatewayProxyEventV2) => Promise<{
    isAuthorized: boolean;
}>;
