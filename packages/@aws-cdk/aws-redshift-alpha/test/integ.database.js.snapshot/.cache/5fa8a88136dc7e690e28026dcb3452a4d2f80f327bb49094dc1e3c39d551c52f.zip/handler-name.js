"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HandlerName = void 0;
var HandlerName;
(function (HandlerName) {
    HandlerName["User"] = "user";
    HandlerName["Table"] = "table";
    HandlerName["UserTablePrivileges"] = "user-table-privileges";
})(HandlerName || (exports.HandlerName = HandlerName = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci1uYW1lLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaGFuZGxlci1uYW1lLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLElBQVksV0FJWDtBQUpELFdBQVksV0FBVztJQUNyQiw0QkFBYSxDQUFBO0lBQ2IsOEJBQWUsQ0FBQTtJQUNmLDREQUE2QyxDQUFBO0FBQy9DLENBQUMsRUFKVyxXQUFXLDJCQUFYLFdBQVcsUUFJdEIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBIYW5kbGVyTmFtZSB7XG4gIFVzZXIgPSAndXNlcicsXG4gIFRhYmxlID0gJ3RhYmxlJyxcbiAgVXNlclRhYmxlUHJpdmlsZWdlcyA9ICd1c2VyLXRhYmxlLXByaXZpbGVnZXMnLFxufVxuIl19