'use strict';

// Load the AWS SDK for Node.js
let AWS = require('aws-sdk');

// Set the region 
AWS.config.update({region: process.env.AWS_REGION});

exports.handler = function(event) {
    const eventText = JSON.stringify(event, null, 2);
    const ddbTable = process.env.DDB_TABLE_NAME;
    
    console.log('Received event:', eventText);
    console.log('Writing eventText to:', ddbTable);

    const item = {
     'id': {
        S: new Date().toISOString()
      },
      'event': {
        S: eventText
      }
    };
    
    const params = {
      TableName: ddbTable,
      Item: item
    };
    
    // Create the DynamoDB service object
    const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    // Call DynamoDB to add the item to the table
    ddb.putItem(params, function(err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        console.log("Success", data);
      }
    });
  };