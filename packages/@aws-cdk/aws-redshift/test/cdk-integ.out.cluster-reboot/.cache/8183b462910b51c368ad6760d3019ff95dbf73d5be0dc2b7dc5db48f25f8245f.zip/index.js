"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
// eslint-disable-next-line import/no-extraneous-dependencies
const aws_sdk_1 = require("aws-sdk");
const redshift = new aws_sdk_1.Redshift();
async function handler(event) {
    if (event.RequestType !== 'Delete') {
        return rebootClusterIfRequired(event.ResourceProperties?.ClusterId, event.ResourceProperties?.ParameterGroupName);
    }
    else {
        return;
    }
}
exports.handler = handler;
async function rebootClusterIfRequired(clusterId, parameterGroupName) {
    return await executeActionForStatus(await getApplyStatus());
    // https://docs.aws.amazon.com/redshift/latest/APIReference/API_ClusterParameterStatus.html
    async function executeActionForStatus(status) {
        if (['pending-reboot', 'apply-deferred', 'apply-error', 'unknown-error'].includes(status)) {
            try {
                await redshift.rebootCluster({ ClusterIdentifier: clusterId }).promise();
            }
            catch (err) {
                if (err.code === 'InvalidClusterState') {
                    await sleep(60000);
                    return await executeActionForStatus(await getApplyStatus());
                }
                else {
                    throw err;
                }
            }
            return;
        }
        else if (['applying', 'retry'].includes(status)) {
            await sleep(60000);
            return await executeActionForStatus(await getApplyStatus());
        }
        return;
    }
    async function getApplyStatus() {
        const clusterDetails = await redshift.describeClusters({ ClusterIdentifier: clusterId }).promise();
        if (clusterDetails.Clusters?.[0].ClusterParameterGroups === undefined) {
            throw new Error(`Unable to find any Parameter Groups associated with ClusterId "${clusterId}".`);
        }
        for (const group of clusterDetails.Clusters?.[0].ClusterParameterGroups) {
            if (group.ParameterGroupName === parameterGroupName) {
                return group.ParameterApplyStatus ?? 'retry';
            }
        }
        throw new Error(`Unable to find Parameter Group named "${parameterGroupName}" associated with ClusterId "${clusterId}".`);
    }
}
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw2REFBNkQ7QUFDN0QscUNBQW1DO0FBRW5DLE1BQU0sUUFBUSxHQUFHLElBQUksa0JBQVEsRUFBRSxDQUFDO0FBRXpCLEtBQUssVUFBVSxPQUFPLENBQUMsS0FBa0Q7SUFDOUUsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFFBQVEsRUFBRTtRQUNsQyxPQUFPLHVCQUF1QixDQUFDLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixFQUFFLGtCQUFrQixDQUFDLENBQUM7S0FDbkg7U0FBTTtRQUNMLE9BQU87S0FDUjtBQUNILENBQUM7QUFORCwwQkFNQztBQUVELEtBQUssVUFBVSx1QkFBdUIsQ0FBQyxTQUFpQixFQUFFLGtCQUEwQjtJQUNsRixPQUFPLE1BQU0sc0JBQXNCLENBQUMsTUFBTSxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBRTVELDJGQUEyRjtJQUMzRixLQUFLLFVBQVUsc0JBQXNCLENBQUMsTUFBYztRQUNsRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN6RixJQUFJO2dCQUNGLE1BQU0sUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUE7YUFDekU7WUFDRCxPQUFPLEdBQUcsRUFBRTtnQkFDVixJQUFVLEdBQUksQ0FBQyxJQUFJLEtBQUsscUJBQXFCLEVBQUU7b0JBQzdDLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNuQixPQUFPLE1BQU0sc0JBQXNCLENBQUMsTUFBTSxjQUFjLEVBQUUsQ0FBQyxDQUFDO2lCQUM3RDtxQkFBTTtvQkFDTCxNQUFNLEdBQUcsQ0FBQTtpQkFDVjthQUNGO1lBQ0QsT0FBTztTQUNSO2FBQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDakQsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkIsT0FBTyxNQUFNLHNCQUFzQixDQUFDLE1BQU0sY0FBYyxFQUFFLENBQUMsQ0FBQztTQUM3RDtRQUNELE9BQU87SUFDVCxDQUFDO0lBRUQsS0FBSyxVQUFVLGNBQWM7UUFDM0IsTUFBTSxjQUFjLEdBQUcsTUFBTSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ25HLElBQUksY0FBYyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixLQUFLLFNBQVMsRUFBRTtZQUNyRSxNQUFNLElBQUksS0FBSyxDQUFDLGtFQUFrRSxTQUFTLElBQUksQ0FBQyxDQUFDO1NBQ2xHO1FBQ0QsS0FBSyxNQUFNLEtBQUssSUFBSSxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLEVBQUU7WUFDdkUsSUFBSSxLQUFLLENBQUMsa0JBQWtCLEtBQUssa0JBQWtCLEVBQUU7Z0JBQ25ELE9BQU8sS0FBSyxDQUFDLG9CQUFvQixJQUFJLE9BQU8sQ0FBQzthQUM5QztTQUNGO1FBQ0QsTUFBTSxJQUFJLEtBQUssQ0FBQyx5Q0FBeUMsa0JBQWtCLGdDQUFnQyxTQUFTLElBQUksQ0FBQyxDQUFDO0lBQzVILENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxLQUFLLENBQUMsRUFBVTtJQUN2QixPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLWV4dHJhbmVvdXMtZGVwZW5kZW5jaWVzXG5pbXBvcnQgeyBSZWRzaGlmdCB9IGZyb20gJ2F3cy1zZGsnO1xuXG5jb25zdCByZWRzaGlmdCA9IG5ldyBSZWRzaGlmdCgpO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihldmVudDogQVdTTGFtYmRhLkNsb3VkRm9ybWF0aW9uQ3VzdG9tUmVzb3VyY2VFdmVudCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoZXZlbnQuUmVxdWVzdFR5cGUgIT09ICdEZWxldGUnKSB7XG4gICAgcmV0dXJuIHJlYm9vdENsdXN0ZXJJZlJlcXVpcmVkKGV2ZW50LlJlc291cmNlUHJvcGVydGllcz8uQ2x1c3RlcklkLCBldmVudC5SZXNvdXJjZVByb3BlcnRpZXM/LlBhcmFtZXRlckdyb3VwTmFtZSk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlYm9vdENsdXN0ZXJJZlJlcXVpcmVkKGNsdXN0ZXJJZDogc3RyaW5nLCBwYXJhbWV0ZXJHcm91cE5hbWU6IHN0cmluZykge1xuICByZXR1cm4gYXdhaXQgZXhlY3V0ZUFjdGlvbkZvclN0YXR1cyhhd2FpdCBnZXRBcHBseVN0YXR1cygpKTtcblxuICAvLyBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vcmVkc2hpZnQvbGF0ZXN0L0FQSVJlZmVyZW5jZS9BUElfQ2x1c3RlclBhcmFtZXRlclN0YXR1cy5odG1sXG4gIGFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVBY3Rpb25Gb3JTdGF0dXMoc3RhdHVzOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAoWydwZW5kaW5nLXJlYm9vdCcsICdhcHBseS1kZWZlcnJlZCcsICdhcHBseS1lcnJvcicsICd1bmtub3duLWVycm9yJ10uaW5jbHVkZXMoc3RhdHVzKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgcmVkc2hpZnQucmVib290Q2x1c3Rlcih7IENsdXN0ZXJJZGVudGlmaWVyOiBjbHVzdGVySWQgfSkucHJvbWlzZSgpXG4gICAgICB9XG4gICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICgoPGFueT5lcnIpLmNvZGUgPT09ICdJbnZhbGlkQ2x1c3RlclN0YXRlJykge1xuICAgICAgICAgIGF3YWl0IHNsZWVwKDYwMDAwKTtcbiAgICAgICAgICByZXR1cm4gYXdhaXQgZXhlY3V0ZUFjdGlvbkZvclN0YXR1cyhhd2FpdCBnZXRBcHBseVN0YXR1cygpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBlcnJcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSBpZiAoWydhcHBseWluZycsICdyZXRyeSddLmluY2x1ZGVzKHN0YXR1cykpIHtcbiAgICAgIGF3YWl0IHNsZWVwKDYwMDAwKTtcbiAgICAgIHJldHVybiBhd2FpdCBleGVjdXRlQWN0aW9uRm9yU3RhdHVzKGF3YWl0IGdldEFwcGx5U3RhdHVzKCkpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBnZXRBcHBseVN0YXR1cygpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGNsdXN0ZXJEZXRhaWxzID0gYXdhaXQgcmVkc2hpZnQuZGVzY3JpYmVDbHVzdGVycyh7IENsdXN0ZXJJZGVudGlmaWVyOiBjbHVzdGVySWQgfSkucHJvbWlzZSgpO1xuICAgIGlmIChjbHVzdGVyRGV0YWlscy5DbHVzdGVycz8uWzBdLkNsdXN0ZXJQYXJhbWV0ZXJHcm91cHMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmFibGUgdG8gZmluZCBhbnkgUGFyYW1ldGVyIEdyb3VwcyBhc3NvY2lhdGVkIHdpdGggQ2x1c3RlcklkIFwiJHtjbHVzdGVySWR9XCIuYCk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgZ3JvdXAgb2YgY2x1c3RlckRldGFpbHMuQ2x1c3RlcnM/LlswXS5DbHVzdGVyUGFyYW1ldGVyR3JvdXBzKSB7XG4gICAgICBpZiAoZ3JvdXAuUGFyYW1ldGVyR3JvdXBOYW1lID09PSBwYXJhbWV0ZXJHcm91cE5hbWUpIHtcbiAgICAgICAgcmV0dXJuIGdyb3VwLlBhcmFtZXRlckFwcGx5U3RhdHVzID8/ICdyZXRyeSc7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgVW5hYmxlIHRvIGZpbmQgUGFyYW1ldGVyIEdyb3VwIG5hbWVkIFwiJHtwYXJhbWV0ZXJHcm91cE5hbWV9XCIgYXNzb2NpYXRlZCB3aXRoIENsdXN0ZXJJZCBcIiR7Y2x1c3RlcklkfVwiLmApO1xuICB9XG59XG5cbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCBtcykpO1xufSJdfQ==