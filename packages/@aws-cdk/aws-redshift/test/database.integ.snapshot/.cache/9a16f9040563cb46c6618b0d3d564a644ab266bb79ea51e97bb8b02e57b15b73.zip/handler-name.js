"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HandlerName = void 0;
var HandlerName;
(function (HandlerName) {
    HandlerName["User"] = "user";
    HandlerName["Table"] = "table";
    HandlerName["UserTablePrivileges"] = "user-table-privileges";
})(HandlerName = exports.HandlerName || (exports.HandlerName = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci1uYW1lLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaGFuZGxlci1uYW1lLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLElBQVksV0FJWDtBQUpELFdBQVksV0FBVztJQUNyQiw0QkFBYSxDQUFBO0lBQ2IsOEJBQWUsQ0FBQTtJQUNmLDREQUE2QyxDQUFBO0FBQy9DLENBQUMsRUFKVyxXQUFXLEdBQVgsbUJBQVcsS0FBWCxtQkFBVyxRQUl0QiIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBlbnVtIEhhbmRsZXJOYW1lIHtcbiAgVXNlciA9ICd1c2VyJyxcbiAgVGFibGUgPSAndGFibGUnLFxuICBVc2VyVGFibGVQcml2aWxlZ2VzID0gJ3VzZXItdGFibGUtcHJpdmlsZWdlcycsXG59XG4iXX0=