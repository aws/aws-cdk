export declare function handler(event: any): {
    PhysicalResourceId: any;
    Data: any;
};
