/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function supported_languages(a: number): void;
export function transmute(a: number, b: number, c: number, d: number, e: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
