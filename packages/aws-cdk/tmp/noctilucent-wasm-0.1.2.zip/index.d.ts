/* tslint:disable */
/* eslint-disable */
/**
* Returns an array containing all supported language names.
* @returns {any[]}
*/
export function supported_languages(): any[];
/**
* Transforms the provided template into a CDK application in the specified
* language.
* @param {string} template
* @param {string} language
* @returns {string}
*/
export function transmute(template: string, language: string): string;
